const handler = async (m, {text, command, args, usedPrefix}) => {
let language = 'es'
m.reply(`${lenguajeGB['smsAvisoAG']()}`)
} 
handler.command = /^(prueba39)$/i
export default handler
